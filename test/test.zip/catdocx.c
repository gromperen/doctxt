#include <stdio.h>
#include <stdlib.h>
#include <archive.h>

void
readzip(char const *file)
{
	struct archive *a;
	struct archive_entry *entry;
	int r;

	a = archive_read_new();

	archive_read_support_format_zip(a);

	r = archive_read_open_filename(a, file, 10240);
	if (r != ARCHIVE_OK)
		exit(1);
	while (archive_read_next_header(a, &entry) == ARCHIVE_OK) {
		printf("%s\n", archive_entry_pathname(entry));
		archive_read_data_skip(a);
	}




}

int
main(int argc, char *argv[])
{
	if (argc != 1) {
		printf("Reading %s", argv[1]);
		readzip(argv[1]);
	}
	return 0;
}
